const mongoose= require('mongoose');
const menSchema= new mongoose.Schema({
    ranking:{
        type:Number,
        reuired:true,
        unique:true
    },
    name:{
        type:String,
        reuired:true,
        trim:true
    },
    dob:{
        type:Date,
        reuired:true,
        trim:true
    },
    country:{
        type:String,
        reuired:true,
        trim:true
    },
    score:{
        type:Number,
        reuired:true,
        trim:true
    },
    event:{
        type:String,
        default:"100m"
    }

})

//we are creating a new collection
const MensRanking = new mongoose.model("MensRanking",menSchema);

module.exports = MensRanking;
 